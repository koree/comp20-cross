var express = require('express');

var mongo = require('mongodb'); 

var app = express();
var bodyParser = require('body-parser');

app.use(bodyParser());

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/comp20'; 



app.get('/', function(req, res) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function(err, col){
      col.find({}).sort({"score": -1}).toArray(function(err, x){
        var indexPage = "<html><body><h1> The High Scores for 2048: </h1>   <table><tr><td><b> Score>>Player>>Date </b></tr></td>";
        for (var i =0; i < x.length; ++i){
          indexPage +=  "<tr><td>" + x[i].score + "  " +  x[i].username+ "  " + x[i].date + "</tr></td>";
        }
        indexPage += "</table></body></html>";
        res.send(indexPage);
      });
    });
  });
});

app.get('/scores.json', function (req, res){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, col){
      var username = req.query.username;
        col.find({"username": username}).sort({"score": -1}).toArray(function(e, x){
        res.send(x);
      });
    });
  });
});

app.post('/submit.json', function (req, res){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  mongo.Db.connect(mongoUri, function (err, db){
    db.collection("scores", function (er, collection){
      var score = parseInt(req.body.score);
      var name = req.body.username;
      var grid = req.body.grid;
      var date = new Date();
      
      var hora = new Date(); //time 
      var year = hora.getFullYear();
      var month = hora.getMonth() + 1;
      var day = hora.getDate();
      var hour = hora.getHours();    //JSON.stringify(this.grid)
      var min = hora.getMinutes();
      if (min <10) min = "0"  + min;
      var time = (month + "/" + day + "/" + year + " " + hour + ":" + min);

      if (name != null && score != null && grid != null) {
        collection.insert({"score": score, "username": name, "date": time, "grid": grid}, function (err, r){});
        res.send(200); // lets know if OK
      }
    });
  });
});

app.listen(process.env.PORT || 3000);

